<?php

require './DataBaseAccess.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$databaseObject = new DataBaseAccess();
$result = $databaseObject->selectUsers();
if (mysqli_num_rows($result) == 0)
    echo "No users to be viewed";
else {
        echo "<table border = 1>"; 
        echo "<tr>"; 
        echo "<th>Name</th>"; 
        echo "<th>Email</th>"; 
        echo "<th>Gender</th>"; 
        echo "<th>Delete</th>";
        echo "</tr>";
        while ($row = mysqli_fetch_array($result)) { 
            echo "<tr>"; 
            echo "<td>".$row['name']."</td>"; 
            echo "<td>".$row['email']."</td>"; 
            echo "<td>".$row['gender']."</td>";
            echo "<td><a href='deleteUser.php?id=$row[id]'>Delete</a></td>";
            echo "</tr>"; 
        } 
        echo "</table>";
        echo "<a href='http://localhost/lab4/index.php'><button>Add a new User </button></a>";
        mysqli_free_res($result);
            
}
