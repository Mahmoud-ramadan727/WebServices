<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 
class Validation {
   public function validateNameLength($name)
    {
        if (strlen($name) >= 11 ){
            return 1;
        }
        elseif(strlen($name) < 2)
        return 0;
        else{
            return 3;
        }
    }
    public function validatNameCharacters($name):bool
     {
        return preg_match('/^[a-zA-z ]+$/',$name);
     }
     
     public function validatEmail($email):bool
         {
            return preg_match('/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix',$email);
         }
         
    public function validateEmailLength($email)
        {
            if(strlen($email) > 30)
            {
                return 0;
            }
            else{
                return 1;
            }
    
        }

}

