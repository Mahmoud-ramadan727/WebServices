<?php
//var_dump($_SERVER["REQUEST_URI"]);
class MyRequestHandler{
    private $method;
    private $paramters=array();
    private $resource;
    private $resource_id;
    private $allowed_method=array('GET','PUT','POST','DELETE');
    function getMethod() {
        return $this->method;
    }

    function getParamters() {
        return $this->paramters;
    }

    function getResource() {
        return $this->resource;
    }

    function getResource_id() {
        return $this->resource_id;
    }
    
    public function __construct() {
        $this->method=$_SERVER['REQUEST_METHOD'];
        $url_piecies = explode('/', $_SERVER['REQUEST_URI']);
        $this->resource= isset($url_piecies[3])?$url_piecies[3]:"";
        $this->resource_id= isset($url_piecies[4])&&is_numeric($url_piecies[4])?$url_piecies[4]:0;
        if($this->method == 'POST'||$this->method=='GET'||$this->method=='DELETE'||$this->method=='PUT'){
            $this->paramters= json_decode(file_get_contents('php://input'),true);
        }
    }
     public function validate($correct_resource,$output = true){
        if($this->resource !== $correct_resource || !is_numeric($this->resource_id)){
            ResponseHandler::output_with_error(404,"resource not found");
         } elseif(!in_array($this->method,$this->allowed_method)){
             ResponseHandler::output_with_error(405,"method not valid");
         } else {
            return true;
        }
        
    }
   
}
