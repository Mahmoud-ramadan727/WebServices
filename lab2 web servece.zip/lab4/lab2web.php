<?php


require 'DataBaseAccess.php';
require 'MyResponseHandler.php';
require 'MyRequestHandler.php';


$db = new DataBaseAccess();
$requestHandler = new MyRequestHandler();
$responseHandler = new MyResponseHandler($db);

$checkedValue = $requestHandler->getResource();

$validate = $requestHandler->validate($checkedValue);
$id = $requestHandler->getResource_id();


if ($validate) {
    switch ($requestHandler->getMethod()) {
        case "GET":
            if($id!=null){
                 $responseHandler->handle_get($id);
            } else {
                  $responseHandler->handle_get_all(); 
            }
         
            break;

        case "DELETE":
            $responseHandler->handle_delete($id);
            break;
        case "POST":
            $responseHandler->handle_post(25,'ahmed','ahmed@gmail.com','male');
        break;


    }
}



