<?php

// return a result as in the requirment 
//to call a function you must use the $this-> method_name

 
require './DBInterface.php';
class DataBaseAccess {

    protected $serverName = "localhost";
    protected $userName = "root";
    protected $password = "password";
    protected $databaseName = "phpDatabase";
    protected $portNumber = 3306;

    public function connectToDataBase() {

        return new mysqli($this->serverName, $this->userName, $this->password, $this->databaseName, $this->portNumber);
	if ($connection->connect_error) {
            die("Connection failed: " . $connection->connect_error);
        }
        
    }

    public function disconnect(mysqli $connection) {
        $connection->close();
    }

    public function selectUsers() {

        $connection = $this->connectToDataBase();
        
        $result = $connection->query("SELECT * FROM employees");
        $this->disconnect($connection);
        return $result;
        
    }
     public function selectUser($id) {

        $connection = $this->connectToDataBase();
        
        $result = $connection->query("SELECT * FROM employees where id=".$id);
        $this->disconnect($connection);
        return $result;
        
    }

    public function insertUser($id , $firstName , $email, $gender) {

        $connection = $this->connectToDataBase();
         
        $sql = "insert into employees (id,name,email,gender) values (?,?,?,?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('dsss',$id , $firstName, $email, $gender);
        if ($stmt->execute()) {
            echo "user added successfully!!";
        }
        $this->disconnect($connection);
    }

    public function deleteUser($id) {
        $connection  =$this->connectToDataBase();
         
        
        $sql = "delete from employees where id=?";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo "user deleted successfully!!";
        }
        $this->disconnect($connection);
        
    }

}

// create table employees
// (
//  id INT(11) NOT NULL AUTO_INCREMENT,
//  name varchar(255),
//  email varchar(255),
//  gender varchar(255)
 
       
// )





