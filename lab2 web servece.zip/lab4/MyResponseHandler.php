<?php

class MyResponseHandler{
    private $database;
    //private $logger;
    function __construct($database) {
        $this->database = $database;
        //$this->logger = $logger;
    }
    public function output_with_success($data, $sucess_code = 200, $log = null) {
		header("Content-Type:application/json");
		$output = json_encode($data);
		if(!$output){
			self::output_with_error(400,"Resource not found");
		} else {
			http_response_code($sucess_code);
			echo $output;
		}
		/*if(is_null($log)){
			$log -> info("SENT");
			exit();
		}*/

    }
    public static function output_with_error($code = 400, $error_msg, $log = null) {
		header("Content-Type:application/json");
		http_response_code($code);
		//echo json_encode(array("error"=>$error_msg));
		/*if(is_null($log)){
			//$log->info("sent");
			exit();
		}*/
    }
      public function handle_get($id) {

		$data = $this->database->selectUser($id);
		if($data->num_rows>0){
			self::output_with_success($data->fetch_assoc());
		}
		else {
			self::output_with_error(404,"resource not here");
		} 
    }
    public function handle_get_all() {

		$data = $this->database->selectUsers();
		if($data->num_rows>0){
			self::output_with_success($data->fetch_all());
		}
		else {
			self::output_with_error(404,"resource not here");
		} 
    }
      
     public function handle_post($id,$name,$email,$gender) {
		if($this->database->insertUser($id,$name,$email,$gender)){
			self::output_with_success(array("status"=>"userAdded"));
		}
		else{
			self::output_with_error(400,"request not valid");
		}
     
    }
    public function handle_delete($id) {
		if($this->database->deleteUser($id)){
			self::output_with_success(array("status"=>"deleted successfully"));
		}
		else{
			self::output_with_error(400,"request not valid");
		}
    }

}

