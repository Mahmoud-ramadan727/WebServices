<?php

require './Validation.php';
require './DataBaseAccess.php';

require './form.html';
$first = false;
$second = false;
$third = false;
$validationObject = new Validation();


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    if (isset($_POST['name']) && !empty($_POST['name'])) {
        $name = $_POST['name'];
        if ($validationObject->validateNameLength($name) == 1) {
            echo "<h3> name maximum length is 10 </h3>";
        }
        if ($validationObject->validateNameLength($name) == 0) {
            echo "<h3> name minimum length is 2 </h3>";
        }
        if ($validationObject->validatNameCharacters($name) == false) {
            echo "<h3> name must contain characters only</h3>";
        }
        $first = true;
    } else {
        echo "<h3> name is required </h3>";
    }
    if (isset($_POST['email']) && !empty($_POST['email'])) {
        $email = $_POST['email'];
        if ($validationObject->validatEmail($email) == false) {
            echo "<h3> please enter a valid email address!</h3>";
        }
        if ($validationObject->validateEmailLength($email) == 0) {
            echo "<h3> email maximum 20</h3>";
        }
        $second = true;
    } else {
        echo "<h3> email is required </h3>";
    }

    if ((isset($_POST['gender1']) && !empty($_POST['gender1'])) ||
            ( isset($_POST['gender2']) && !empty($_POST['gender2']))) {
        if (!empty($_POST['gender1'])) {
            $gender = $_POST['gender1'];
        }
        if (!empty($_POST['gender2'])) {
            $gender = $_POST['gender2'];
        }
        $third = true;
    } else {
        echo "<h3> gender is required </h3>";
    }

    if ($first && $second && $third) {

        $databaseObject = new DataBaseAccess();
        $databaseObject->insertUser($name, $email, $gender);
        header("Location: http://localhost/lab4/allUsers.php");
        $databaseObject ->deleteUser(27);

    }
}
?>