<?php
require 'DataBaseAccess.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if (isset($_GET['id'])&& !empty($_GET['id'])) {
    $databaseObject = new DataBaseAccess();
    $connection =  $databaseObject ->connectToDataBase();
    if($connection->connect_error) 
            die("Connection failed: " . $connection->connect_error);
    $sql = "delete from employees where id=?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("s",$_GET['id']);
    $stmt->execute();
    header("Location: http://localhost/lab4/allUsers.php");
        
    
}